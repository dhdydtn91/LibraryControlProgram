package View;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.Color;
import java.util.List;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.UIManager;

import model.Message;

import javax.swing.JButton;
import javax.swing.ScrollPaneConstants;

public class MessageSend extends JFrame{
	public JTextField tftTo;
	public JTextField tftTitle;
	public JButton btnSend;
	public JButton btnMsgSendCancel;
	public JTextArea tpContent;
		public MessageSend(List<Object> list,Boolean isplay) {
			
			getContentPane().setLayout(null);
			
			JLabel lbTitle = new JLabel("Title");
			lbTitle.setHorizontalAlignment(SwingConstants.CENTER);
			lbTitle.setBounds(54, 39, 57, 15);
			getContentPane().add(lbTitle);
			
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			scrollPane.setBounds(63, 69, 249, 248);
			getContentPane().add(scrollPane);
			
			tpContent = new JTextArea();
			tpContent.setLineWrap(true);
			tpContent.setRows(10);
			tpContent.setColumns(1);
			scrollPane.setViewportView(tpContent);
			
			btnSend = new JButton("Send");
			btnSend.setBackground(Color.WHITE);
			btnSend.setBounds(63, 339, 97, 23);
			getContentPane().add(btnSend);
			
			btnMsgSendCancel = new JButton("Cancel");
			btnMsgSendCancel.setBackground(Color.WHITE);
			btnMsgSendCancel.setBounds(215, 339, 97, 23);
			getContentPane().add(btnMsgSendCancel);
			
			JLabel lblTo = new JLabel("To");
			lblTo.setHorizontalAlignment(SwingConstants.CENTER);
			lblTo.setBounds(54, 14, 57, 15);
			getContentPane().add(lblTo);
			
			if(isplay){
			    Message Msg=(Message) list.get(0);
				tftTo = new JTextField(Msg.getMsgSendid());
				}else{
					tftTo = new JTextField("");
				} //JTable �ο츦 �����ϸ� ������ ���̵� �÷��� ���� �ƴҰ�� ��ĭ
			
			tftTo.setBounds(123, 11, 189, 23);
			getContentPane().add(tftTo);
			tftTo.setColumns(10);
			
			tftTitle = new JTextField();
			tftTitle.setColumns(10);
			tftTitle.setBounds(123, 36, 189, 23);
			getContentPane().add(tftTitle);
			setVisible(true);
			setSize(400, 473);
	}
}
