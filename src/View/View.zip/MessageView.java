package View;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.Color;
import java.util.List;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.UIManager;

import model.Message;

import javax.swing.JButton;
import javax.swing.ScrollPaneConstants;

public class MessageView extends JFrame{
	public JButton btnReply;
	public JButton btnMsgViewDelete;
	public JLabel lbMsgViewFrom;
	public JLabel lblMsgViewTitle;
	
	public MessageView(List<Object> list) {
		getContentPane().setLayout(null);
		Message Msg=(Message) list.get(0);
		JLabel lblMsgViewTitleLogo = new JLabel("Title");
		lblMsgViewTitleLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblMsgViewTitleLogo.setBounds(54, 40, 57, 15);
		getContentPane().add(lblMsgViewTitleLogo);
		
		lblMsgViewTitle = new JLabel(Msg.getMsgTitle());
		lblMsgViewTitle.setBounds(123, 40, 171, 15);
		getContentPane().add(lblMsgViewTitle);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(63, 69, 249, 248);
		getContentPane().add(scrollPane);
		
		JTextArea tpContent = new JTextArea(Msg.getMsgContent());
		tpContent.setLineWrap(true);
		tpContent.setBackground(Color.WHITE);
		tpContent.setEditable(false);
		scrollPane.setViewportView(tpContent);
		
		btnReply = new JButton("Reply");
		btnReply.setBackground(Color.WHITE);
		btnReply.setBounds(63, 339, 97, 23);
		getContentPane().add(btnReply);
		
		btnMsgViewDelete = new JButton("Delete");
		btnMsgViewDelete.setBackground(Color.WHITE);
		btnMsgViewDelete.setBounds(215, 339, 97, 23);
		getContentPane().add(btnMsgViewDelete);
		
		JLabel lbMsgViewFromLogo = new JLabel("From");
		lbMsgViewFromLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lbMsgViewFromLogo.setBounds(54, 15, 57, 15);
		getContentPane().add(lbMsgViewFromLogo);
		
		lbMsgViewFrom = new JLabel(Msg.getMsgSendid());
		lbMsgViewFrom.setBounds(123, 15, 171, 15);
		getContentPane().add(lbMsgViewFrom);
		setVisible(true);
		setSize(400, 473);
	
	}
}
